<template>
    <div class="detailspage"> 
				<img src="https://languanzhao.github.io/img-for-app-project/pro_details_content.png" class="pro_content">
    </div>
</template>

<script>
    export default{
       name:'detailspage'
    }
</script>

<style scoped>
.pro_content{width: 750px;padding-bottom: 100px;}
</style>
