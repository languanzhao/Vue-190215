<template>
	<div class="modelTwo">
		<slot name="left"></slot>
		<slot name="right"></slot>
	</div>
</template>

<script>
	export default{
		name:"modelTwo"
	}
	
</script>

<style scoped>

</style>