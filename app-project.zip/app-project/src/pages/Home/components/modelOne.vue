<template>
	<div class="modelOne">
		<slot name="left"></slot>
		<slot name="right"></slot>
	</div>
</template>

<script>
	export default{
		name:"modelOne"
	}
	
</script>

<style scoped>

</style>