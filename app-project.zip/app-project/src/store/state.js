const stateData = {
	count:0,
	start:0
}
export default stateData