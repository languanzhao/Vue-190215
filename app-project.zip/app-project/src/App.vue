<template>
  <div id="app">
    <router-view/>           <!-- 注：不能去掉，否则不能显示路由 -->
  </div>
</template>

<style>

</style>
